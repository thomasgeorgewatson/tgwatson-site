// Pure formatting helpers shared by the popup and the background service worker.
// No DOM, no chrome.* — safe to unit-test in plain Node.
//
// The content script returns raw timestamped segments; everything that turns those
// into readable prose (paragraph grouping, chapter sectioning, Markdown assembly)
// lives here so the popup and the batch archiver produce byte-identical output.

/** Parse a YouTube clock string ("0:07", "1:52:10") into seconds. */
export function parseClock(raw) {
  const m = String(raw ?? "")
    .trim()
    .match(/^(?:(\d+):)?(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  return (m[1] ? Number(m[1]) * 3600 : 0) + Number(m[2]) * 60 + Number(m[3]);
}

/** Seconds → "M:SS", or "H:MM:SS" once we're past an hour. */
export function formatClock(seconds) {
  const s = Math.max(0, Math.floor(Number(seconds) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = String(s % 60).padStart(2, "0");
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
}

export function videoUrl(videoId) {
  return videoId ? `https://www.youtube.com/watch?v=${videoId}` : "";
}

/** Deep link to a specific second of a video. */
export function videoUrlAt(videoId, seconds) {
  const base = videoUrl(videoId);
  if (!base) return "";
  return `${base}&t=${Math.max(0, Math.floor(Number(seconds) || 0))}s`;
}

function tidy(text) {
  return String(text)
    .replace(/\s+/g, " ")
    .replace(/\s([,.!?;:])/g, "$1")
    .trim();
}

/**
 * Estimate how fast this particular speaker talks, in words per second, as the
 * median of each segment's words ÷ the gap before the next segment starts.
 *
 * A fixed constant misjudges real videos badly in both directions: measured live,
 * the Stanford commencement address runs about 1.7 w/s and a fixed 2.2 chopped it
 * into needless fragments, while fast conversational channels run past 3. The
 * median shrugs off the outliers that genuine pauses create — those are exactly
 * the breaks we're trying to detect, so they must not drag the baseline down.
 */
export function estimateWordsPerSecond(segments, fallback = 2.2) {
  const rates = [];
  for (let i = 0; i < segments.length - 1; i++) {
    const t = segments[i]?.t;
    const next = segments[i + 1]?.t;
    if (typeof t !== "number" || typeof next !== "number") continue;
    const gap = next - t;
    if (gap <= 0) continue;
    const words = String(segments[i].text || "").split(/\s+/).filter(Boolean).length;
    if (!words) continue;
    rates.push(words / gap);
  }
  if (rates.length < 5) return fallback;

  rates.sort((a, b) => a - b);
  const mid = Math.floor(rates.length / 2);
  const median =
    rates.length % 2 ? rates[mid] : (rates[mid - 1] + rates[mid]) / 2;

  // Clamp to plausible human speech so a pathological transcript can't produce
  // either one giant paragraph or one paragraph per segment.
  return Math.min(4, Math.max(1.2, median));
}

/**
 * Group caption segments into readable paragraphs.
 *
 * Auto-generated captions arrive as ~2-second fragments with no punctuation, so a
 * naive join is an unreadable wall. We break on inferred *pauses*: caption segment
 * start times are spaced by how long the segment was on screen, so a gap that is
 * much longer than the segment's word count justifies means the speaker stopped.
 * Hard caps on paragraph duration and length keep dense speech from running away.
 *
 * @param {{t: number|null, text: string}[]} segments
 * @returns {{t: number, text: string}[]}
 */
export function groupSegments(segments, opts = {}) {
  const {
    minGapSeconds = 2.5,
    pauseSlackSeconds = 2,
    wordsPerSecond = estimateWordsPerSecond(segments),
    minSeconds = 15,
    hardPauseSeconds = 10,
    maxSeconds = 45,
    maxChars = 700,
  } = opts;

  const paragraphs = [];
  let cur = null;

  const flush = () => {
    if (!cur) return;
    const text = tidy(cur.parts.join(" "));
    if (text) paragraphs.push({ t: cur.t, text });
    cur = null;
  };

  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    if (!seg?.text) continue;
    const t = typeof seg.t === "number" ? seg.t : null;

    if (!cur) cur = { t: t ?? (paragraphs.at(-1)?.t ?? 0), parts: [], chars: 0 };
    cur.parts.push(seg.text);
    cur.chars += seg.text.length + 1;

    const next = segments[i + 1];
    if (!next) break;
    const nextT = typeof next.t === "number" ? next.t : null;

    let breakHere = cur.chars >= maxChars;
    if (!breakHere && t !== null && nextT !== null) {
      const gap = nextT - t;
      const words = seg.text.split(/\s+/).filter(Boolean).length;
      const spoken = words / wordsPerSecond;
      // A pause needs both an absolute floor (sub-2.5s gaps are just normal caption
      // pacing) and a gap materially longer than the segment's word count justifies.
      const isPause = gap >= minGapSeconds && gap - spoken > pauseSlackSeconds;
      // ...but don't strand a one-line paragraph on a marginal pause. Below
      // minSeconds only an unmistakable silence is allowed to break.
      const longEnough = nextT - cur.t >= minSeconds || gap >= hardPauseSeconds;
      if (isPause && longEnough) breakHere = true;
      if (nextT - cur.t >= maxSeconds) breakHere = true;
    }
    if (breakHere) flush();
  }

  flush();
  return paragraphs;
}

/**
 * Slice paragraphs into chapter sections. Anything before the first chapter marker
 * becomes a leading section with a null title.
 */
export function sectionize(paragraphs, chapters) {
  if (!chapters?.length) return [{ title: null, t: null, paragraphs }];

  const sorted = [...chapters].sort((a, b) => a.t - b.t);
  const sections = [];
  const lead = paragraphs.filter((p) => p.t < sorted[0].t);
  if (lead.length) sections.push({ title: null, t: null, paragraphs: lead });

  sorted.forEach((ch, i) => {
    const end = sorted[i + 1]?.t ?? Infinity;
    const inside = paragraphs.filter((p) => p.t >= ch.t && p.t < end);
    if (inside.length) sections.push({ title: ch.title, t: ch.t, paragraphs: inside });
  });

  return sections;
}

/** Plain-text rendering for the popup preview and the Copy button. */
export function buildPlainText(data, { timestamps = true } = {}) {
  const paragraphs = groupSegments(data.segments || []);
  const sections = sectionize(paragraphs, data.chapters);
  const out = [];

  for (const section of sections) {
    if (section.title) {
      out.push(`## ${timestamps ? `[${formatClock(section.t)}] ` : ""}${section.title}`);
    }
    for (const p of section.paragraphs) {
      out.push(timestamps ? `[${formatClock(p.t)}] ${p.text}` : p.text);
    }
  }

  return out.join("\n\n").trim();
}

/** Obsidian-ready Markdown: YAML frontmatter + linked chapters + linked paragraphs. */
export function buildMarkdown(data, { timestamps = true } = {}) {
  const {
    videoTitle,
    videoId,
    channelName,
    durationText,
    publishedDate,
    isAutoGenerated,
    languageLabel,
    possiblyTruncated,
  } = data;

  const url = videoUrl(videoId);
  const capturedAt = new Date().toISOString().slice(0, 10);

  const fm = ["---"];
  fm.push(`title: ${yamlString(videoTitle || "Untitled")}`);
  if (url) fm.push(`source: ${yamlString(url)}`);
  if (videoId) fm.push(`video_id: ${yamlString(videoId)}`);
  if (channelName) fm.push(`channel: ${yamlString(channelName)}`);
  if (durationText) fm.push(`duration: ${yamlString(durationText)}`);
  if (publishedDate) fm.push(`published: ${yamlString(publishedDate)}`);
  if (languageLabel) fm.push(`captions: ${yamlString(languageLabel)}`);
  if (isAutoGenerated !== null && isAutoGenerated !== undefined) {
    fm.push(`transcript_source: ${isAutoGenerated ? "auto-generated" : "manual"}`);
  }
  fm.push(`captured: ${capturedAt}`);
  if (possiblyTruncated) fm.push("incomplete: true");
  fm.push("tags: [youtube, transcript]");
  fm.push("---");

  const body = ["", `# ${videoTitle || "Untitled"}`, ""];
  if (url) body.push(`[Watch on YouTube](${url})`, "");
  if (possiblyTruncated) {
    body.push(
      "> [!warning] Possibly incomplete",
      "> YouTube was still painting transcript segments when this was captured. Re-run the capture to be sure you have the whole thing.",
      ""
    );
  }
  body.push("## Transcript", "");

  const paragraphs = groupSegments(data.segments || []);
  const sections = sectionize(paragraphs, data.chapters);

  for (const section of sections) {
    if (section.title) {
      const heading = timestamps && videoId
        ? `### [${formatClock(section.t)}](${videoUrlAt(videoId, section.t)}) ${section.title}`
        : `### ${section.title}`;
      body.push(heading, "");
    }
    for (const p of section.paragraphs) {
      if (timestamps && videoId) {
        body.push(`**[${formatClock(p.t)}](${videoUrlAt(videoId, p.t)})** ${p.text}`, "");
      } else if (timestamps) {
        body.push(`**[${formatClock(p.t)}]** ${p.text}`, "");
      } else {
        body.push(p.text, "");
      }
    }
  }

  return fm.join("\n") + "\n" + body.join("\n");
}

export function yamlString(s) {
  // Double-quoted YAML scalar: escape backslashes and double quotes.
  return `"${String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}

export function slugify(s) {
  return (s || "")
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}
