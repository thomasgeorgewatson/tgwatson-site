// YTranscript background service worker.
//
// Owns the bulk archiver: given a list of video IDs scraped from a channel or
// playlist page, it opens each one in a hidden tab, injects content.js, pulls the
// transcript, writes a Markdown file, and closes the tab. The job lives here rather
// than in the popup because the popup is destroyed the moment it loses focus —
// the worker keeps going and the popup just re-attaches to the running job.
//
// MV3 caveats this code works around:
//  * Service workers have no URL.createObjectURL, so downloads go out as data: URLs.
//  * Workers are torn down when idle. The job loop makes a chrome.* call every few
//    seconds, which resets the idle timer, and job state is mirrored into
//    chrome.storage.session so a teardown mid-job can be resumed rather than lost.
//  * Hidden tabs get their setTimeout throttled to ~1s, which is why content.js
//    leans on a MutationObserver and generous timeouts.

import { buildMarkdown, slugify } from "./shared/format.js";
import { readCaptionTrack } from "./shared/player.js";

const JOB_KEY = "archiveJob";
const ARCHIVED_KEY = "archivedVideoIds";
const THROTTLE_MS = 1200;
const PER_VIDEO_TIMEOUT_MS = 90000;

let job = null;
let running = false;

// ------------------------------------------------------------------ messaging

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const handlers = {
    GET_JOB: async () => ({ ok: true, job: await loadJob() }),
    START_ARCHIVE: () => startArchive(msg),
    CANCEL_ARCHIVE: async () => {
      const current = await loadJob();
      if (current && current.status === "running") {
        current.status = "cancelled";
        job = current;
        await saveJob();
      }
      return { ok: true, job };
    },
    CLEAR_JOB: async () => {
      job = null;
      await chrome.storage.session.remove(JOB_KEY);
      return { ok: true };
    },
  };

  const handler = handlers[msg?.type];
  if (!handler) return false;

  Promise.resolve(handler())
    .then(sendResponse)
    .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
  return true;
});

// Resume an interrupted job if the worker was torn down mid-run.
(async () => {
  const saved = await loadJob();
  if (saved?.status === "running" && !running) {
    job = saved;
    runJob();
  }
})();

// ----------------------------------------------------------------- job driver

async function startArchive({ videos, sourceName, skipExisting = true, timestamps = true }) {
  const existing = await loadJob();
  if (existing?.status === "running") return { ok: false, error: "An archive job is already running." };
  if (!videos?.length) return { ok: false, error: "Nothing to archive." };

  job = {
    id: `job-${Date.now()}`,
    sourceName: sourceName || "YouTube",
    folder: `YTranscript/${slugify(sourceName) || "youtube"}`,
    queue: videos,
    index: 0,
    total: videos.length,
    done: [],
    skipped: [],
    failed: [],
    current: null,
    status: "running",
    skipExisting,
    timestamps,
    startedAt: new Date().toISOString(),
  };
  await saveJob();
  runJob(); // deliberately not awaited — the popup gets its ack immediately
  return { ok: true, job };
}

async function runJob() {
  if (running) return;
  running = true;

  try {
    const archived = new Set(await loadArchived());

    while (job && job.status === "running" && job.index < job.queue.length) {
      const video = job.queue[job.index];
      job.current = video;
      await saveJob();

      try {
        if (job.skipExisting && archived.has(video.videoId)) {
          job.skipped.push(video);
        } else {
          const data = await withTimeout(
            scrapeInTab(video.videoId),
            PER_VIDEO_TIMEOUT_MS,
            "Timed out on this video."
          );
          const markdown = buildMarkdown(data, { timestamps: job.timestamps });
          await downloadMarkdown(job.folder, data, markdown);
          archived.add(video.videoId);
          await saveArchived(archived);
          job.done.push({ ...video, title: data.videoTitle || video.title });
        }
      } catch (err) {
        job.failed.push({ ...video, error: err?.message || String(err) });
      }

      job.index++;
      await saveJob();
      if (job.status === "running" && job.index < job.queue.length) await sleep(THROTTLE_MS);
    }

    if (job && job.status === "running") job.status = "done";
    if (job) {
      job.current = null;
      job.finishedAt = new Date().toISOString();
      await saveJob();
      await notifyFinished(job);
    }
  } finally {
    running = false;
  }
}

async function scrapeInTab(videoId) {
  const tab = await chrome.tabs.create({
    url: `https://www.youtube.com/watch?v=${videoId}`,
    active: false,
  });

  // Every await below is individually bounded so the finally always runs. A bare
  // sendMessage to a tab whose content script died never settles, which would
  // strand a hidden tab per stuck video across a long archive run.
  try {
    await withTimeout(waitForContentScript(tab.id), 40000, "Page never became ready.");
    const res = await withTimeout(
      chrome.tabs.sendMessage(tab.id, { type: "GET_TRANSCRIPT" }),
      45000,
      "Transcript request timed out."
    );
    if (!res?.ok) throw new Error(res?.error || "Transcript unavailable.");
    const track = await readCaptionTrack(tab.id, videoId);
    return track ? { ...res, ...track } : res;
  } finally {
    try {
      await chrome.tabs.remove(tab.id);
    } catch {
      /* tab may already be gone */
    }
  }
}

/**
 * Inject content.js and ping it until it answers. We avoid the "tabs" permission
 * (and its scary install warning) by probing instead of listening for onUpdated —
 * injection simply fails while the document is still being created, so we retry.
 */
async function waitForContentScript(tabId, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  let lastError = "Page never became ready.";

  while (Date.now() < deadline) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      const pong = await chrome.tabs.sendMessage(tabId, { type: "PING" });
      if (pong?.ok) return;
    } catch (err) {
      lastError = err?.message || String(err);
    }
    await sleep(500);
  }
  throw new Error(lastError);
}

async function downloadMarkdown(folder, data, markdown) {
  const name = slugify(data.videoTitle) || data.videoId || "transcript";
  try {
    await chrome.downloads.download({
      url: toDataUrl(markdown),
      filename: `${folder}/${name}.md`,
      conflictAction: "overwrite",
      saveAs: false,
    });
  } catch (err) {
    throw new Error(`Download failed: ${err?.message || err}`);
  }
}

function toDataUrl(text) {
  // btoa() is latin1-only, so encode to UTF-8 bytes first or emoji in titles throw.
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return `data:text/markdown;charset=utf-8;base64,${btoa(binary)}`;
}

async function notifyFinished(finished) {
  const badge = finished.failed.length ? `${finished.failed.length}!` : "";
  try {
    await chrome.action.setBadgeText({ text: badge });
    if (badge) await chrome.action.setBadgeBackgroundColor({ color: "#cc0000" });
  } catch {
    /* badge is a nicety */
  }
}

// ------------------------------------------------------------------- plumbing

async function loadJob() {
  if (job) return job;
  const stored = await chrome.storage.session.get(JOB_KEY);
  job = stored[JOB_KEY] || null;
  return job;
}

async function saveJob() {
  if (!job) return;
  await chrome.storage.session.set({ [JOB_KEY]: job });
}

async function loadArchived() {
  const stored = await chrome.storage.local.get(ARCHIVED_KEY);
  return stored[ARCHIVED_KEY] || [];
}

async function saveArchived(set) {
  await chrome.storage.local.set({ [ARCHIVED_KEY]: [...set] });
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function withTimeout(promise, ms, message) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(message)), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      }
    );
  });
}
