# YTranscript

A Chrome / Brave extension that grabs YouTube transcripts — one video at a time, or a
whole channel or playlist in bulk. Timestamped, chapter-sectioned, and written as
Obsidian-ready Markdown. No servers, no tracking.

## Install (unpacked, for personal use)

1. Open your browser's extensions page:
   - **Brave:** `brave://extensions`
   - **Chrome:** `chrome://extensions`
2. Enable **Developer mode** (top-right toggle).
3. Click **Load unpacked** and pick this folder (`YTranscript/`).
4. Pin the extension from the toolbar puzzle icon so it's one click away.

## Use

### One video

Open a video and click the icon. The popup shows the transcript; hit **Copy** or
**Download .md**. The **Timestamps & chapter links** toggle controls both — off gives
you clean prose for pasting into an LLM, on gives you clickable deep links.

There's no need to reload the page first. The content script is injected on demand,
so arriving at a video by clicking a thumbnail works exactly like a fresh page load.

### A whole channel or playlist

Open a channel (`/@handle`, its **Videos** tab) or a playlist, then click the icon.
The popup offers **Scan page for videos** — it scroll-loads the list, counts what it
found, and hands you an **Archive** button.

The scan lists every title it found. **Check that list before clicking Archive** — it's
there so a bad scan is obvious before anything is written to disk.

Each video is then opened in a hidden background tab, scraped, written to
`Downloads/YTranscript/<channel-or-playlist>/<video-title>.md`, and closed. Progress
is tracked in the popup, and the job keeps running in the background service worker
if you close the popup or switch tabs. Already-archived videos are skipped by default
so you can re-run a channel to pick up new uploads.

Search-results pages are deliberately not supported — they mix in playlist cards and
"Now playing" shelves whose links also point at `/watch`, so a scan there would return
a list you'd have to hand-audit.

## Output format

```markdown
---
title: "Steve Jobs' 2005 Stanford Commencement Address"
source: "https://www.youtube.com/watch?v=UF8uR6Z6KLc"
video_id: "UF8uR6Z6KLc"
channel: "Stanford"
duration: "15:04"
published: "Mar 7, 2008"
captions: "English"
transcript_source: manual
captured: 2026-08-05
tags: [youtube, transcript]
---

# Steve Jobs' 2005 Stanford Commencement Address

[Watch on YouTube](https://www.youtube.com/watch?v=UF8uR6Z6KLc)

## Transcript

### [0:00](https://www.youtube.com/watch?v=UF8uR6Z6KLc&t=0s) Intro

**[0:07](https://www.youtube.com/watch?v=UF8uR6Z6KLc&t=7s)** This program is brought to
you by Stanford University. Please visit us at stanford.edu
```

Every timestamp is a deep link straight back to that second of the video, so a
transcript in Obsidian stays connected to the source.

**Paragraphs.** Auto-generated captions arrive as ~2-second fragments with no
punctuation. `groupSegments()` rejoins them and breaks on inferred pauses: caption
segments are spaced by how long each was on screen, so a gap much longer than the
segment's word count justifies means the speaker stopped. The speaking rate is
measured per video (median words ÷ gap) rather than assumed — a fixed constant
over-splits slow speakers and under-splits fast ones.

**Chapters** become `###` headings when the video has them, read from the chapters
panel (or parsed out of a `0:00`-anchored timestamp list in the description).

**Incomplete captures** are flagged, not hidden. If YouTube was still painting
segments when the deadline hit, the file gets `incomplete: true` in its frontmatter
and a warning callout in the body.

## How it works

The popup (or the background worker, for bulk jobs) injects `content.js` into the
page with `chrome.scripting.executeScript`, then messages it. The content script
clicks YouTube's own "Show transcript" button — even while it's hidden inside the
collapsed description, the click handler still fires — waits for the transcript panel
to finish populating, reads the rendered segments, and closes the panel again if it
was the one that opened it.

Two "cleaner" approaches don't work in 2026:

- Fetching `ytInitialPlayerResponse.captions.playerCaptionsTracklistRenderer.captionTracks[].baseUrl`
  (the `/api/timedtext` URL) returns an empty 200 body to page-context requests.
- Calling `/youtubei/v1/get_transcript` directly returns `FAILED_PRECONDITION` without
  correctly-signed `SAPISIDHASH` auth, and reproducing that is fragile enough to break
  on YouTube's schedule, not ours.

DOM scraping is uglier but it's what survives YouTube's tightening of the caption
endpoints — and it lets YouTube do the auth for us.

### Waiting for segments

The panel paints its transcript in waves on long videos. Rather than waiting a fixed
delay (which silently returned a partial transcript that looked like a clean success),
`waitForSegments()` resolves only once the segment count has stopped growing, backed
by a `MutationObserver` so it stays accurate in background tabs where Chrome throttles
`setTimeout` to ~1s.

### Detecting auto-generated captions

YouTube's modern transcript panel (`target-id="PAmodern_transcript_view"`) ships no
footer and no language control — there is no node anywhere inside it naming the track.
So `shared/player.js` injects a tiny MAIN-world probe that reads the player's own
caption tracklist (`kind: "asr"` ⇒ auto-generated) and cross-checks the video ID to
avoid acting on a stale player response. The older panel's DOM label is still read as
a fallback.

## Permissions

| Permission | Why |
| --- | --- |
| `scripting` | Inject `content.js` on demand (and the MAIN-world caption probe) |
| `downloads` | Write Markdown files during bulk archiving |
| `storage` | Remember your toggles, the archived-video index, and in-flight job state |
| `https://*.youtube.com/*` | The only site the extension touches |

## Files

- `manifest.json` — MV3
- `content.js` — injected on demand; transcript scraping + channel/playlist collection
- `background.js` — service worker; the bulk archive job engine
- `shared/format.js` — paragraph grouping, chapter sectioning, Markdown assembly
- `shared/player.js` — MAIN-world caption-track probe
- `popup.html` / `popup.js` / `popup.css` — toolbar popup UI (transcript + archive views)
- `icons/` — regenerate with `python3 icons/generate.py`

## Known limitations

- Videos without captions report "No transcript available for this video."
- We take whatever caption track YouTube renders in the panel (the creator's default).
  There's no language picker yet.
- Bulk archiving writes into your Downloads folder. If Chrome is set to *"Ask where to
  save each file"*, turn that off first or you'll get one dialog per video.
- Files are named from the video title with `conflictAction: "overwrite"`, so two
  videos with identical titles in the same channel folder would collide. The video ID
  is always recorded in the frontmatter.
- If YouTube changes its DOM hooks, the selectors are grouped at the top of
  `content.js`. The collector is deliberately generic (`a[href*="/watch?v="]` scoped to
  a video card) because YouTube rotates its list components regularly.
- The collector scopes every query to `activePageRoot()`. YouTube keeps the previous
  page in the DOM (hidden) after an in-app navigation, so a document-wide scrape of a
  channel reached by clicking through from a video also picks up that video's
  recommendations sidebar. Any new page-scraping code must use the same root.

## Dev

No build step. Edit files, click the reload arrow on the extension's card in
`brave://extensions`, and try it out.

Unit tests for the formatting layer are plain Node — `shared/format.js` has no DOM or
`chrome.*` dependencies, so it can be imported and exercised directly:

```bash
node tests/format.test.mjs
```
