// Popup controller. Talks to the content script running on the Amex tab.

const startBtn = document.getElementById("start");
const stopBtn = document.getElementById("stop");
const minInput = document.getElementById("minDelay");
const maxInput = document.getElementById("maxDelay");
const statusEl = document.getElementById("status");

const AMEX_HOST = "global.americanexpress.com";

function setStatus(html, warn = false) {
  statusEl.innerHTML = html;
  statusEl.classList.toggle("warn", warn);
}

function setRunning(running) {
  startBtn.style.display = running ? "none" : "block";
  stopBtn.style.display = running ? "block" : "none";
  minInput.disabled = running;
  maxInput.disabled = running;
}

async function activeAmexTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes(AMEX_HOST)) return null;
  return tab;
}

async function send(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    return null; // content script not present on this page
  }
}

// Live progress pushed from the content script.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "PROGRESS") {
    setStatus(`Adding offers… <b>${msg.added}</b> added.`);
    setRunning(true);
  } else if (msg.type === "DONE") {
    setStatus(`Done. <b>${msg.added}</b> offers added.`);
    setRunning(false);
  }
});

startBtn.addEventListener("click", async () => {
  const tab = await activeAmexTab();
  if (!tab) {
    setStatus(
      "Open your <b>Amex Offers</b> page in this tab first, then click again.",
      true
    );
    return;
  }
  const minDelay = Math.max(100, Number(minInput.value) || 800);
  const maxDelay = Math.max(minDelay, Number(maxInput.value) || 1000);
  const res = await send(tab.id, { type: "START", minDelay, maxDelay });
  if (!res) {
    setStatus("Couldn't reach the page. Reload the Amex tab and retry.", true);
    return;
  }
  setRunning(true);
  setStatus("Starting…");
});

stopBtn.addEventListener("click", async () => {
  const tab = await activeAmexTab();
  if (tab) await send(tab.id, { type: "STOP" });
  setRunning(false);
  setStatus("Stopped.");
});

// On open, sync UI with whatever the content script is doing.
(async () => {
  const tab = await activeAmexTab();
  if (!tab) {
    setStatus("Not on an Amex page. Open your Offers page to begin.", true);
    startBtn.disabled = true;
    return;
  }
  const status = await send(tab.id, { type: "GET_STATUS" });
  if (status && status.running) {
    setRunning(true);
    setStatus(`Adding offers… <b>${status.added}</b> added.`);
  } else if (status) {
    setStatus(`Ready. <b>${status.remaining}</b> offers detected on this page.`);
  }
})();
