// Amex Offers — Add All (content script)
//
// Why the old console snippet bricked:
//   1. It selected button[title="Add to Card"]. Amex now uses
//      title="add to list card" with a stable data-testid. The title text
//      changed, so the selector matched nothing.
//   2. It cached a static NodeList once. Clicking "add" mutates the DOM, so
//      every later index pointed at a stale/wrong node.
//   3. It never scrolled, so lazy-rendered offers further down never loaded.
//
// This script fixes all three: it re-queries the stable data-testid on every
// pass, marks buttons it has already pressed so it can't loop on one, and
// scrolls to pull in the rest before deciding it's done.

(function () {
  if (window.__amexAdderInstalled) return; // avoid double-install on SPA re-inject
  window.__amexAdderInstalled = true;

  // Stable handle on the add button. The CSS-module classes (_iconButton_e2bua_34…)
  // are build-hashed and change every deploy — never select on those.
  const SELECTOR = 'button[data-testid="merchantOfferListAddButton"]';
  const MARK = "data-amex-adder-clicked";
  const LOAD_MORE_RE = /load more|show more|view more|see more|more offers/i;

  const state = { running: false, added: 0, total: 0 };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // Random delay in [min, max] ms — a little jitter so presses aren't robotic.
  const randDelay = (min, max) => min + Math.random() * (max - min);

  function pendingButtons() {
    return Array.from(document.querySelectorAll(SELECTOR)).filter(
      (b) => !b.disabled && b.offsetParent !== null && !b.hasAttribute(MARK)
    );
  }

  // Best-effort: click any "load more / show more" control to reveal more offers.
  function clickLoadMore() {
    const el = Array.from(document.querySelectorAll("button, a")).find(
      (n) => n.offsetParent !== null && LOAD_MORE_RE.test((n.textContent || "").trim())
    );
    if (el) {
      el.click();
      return true;
    }
    return false;
  }

  function report() {
    chrome.runtime
      .sendMessage({ type: "PROGRESS", added: state.added, running: state.running })
      .catch(() => {}); // popup may be closed — fine
  }

  async function run(minDelay, maxDelay) {
    if (state.running) return;
    state.running = true;
    state.added = 0;
    report();

    let emptyPasses = 0;

    while (state.running) {
      const buttons = pendingButtons();

      if (buttons.length === 0) {
        // Nothing visible right now — try to load more before giving up.
        const grewByButton = clickLoadMore();
        const beforeHeight = document.body.scrollHeight;
        window.scrollTo(0, document.body.scrollHeight);
        await sleep(900);
        const grewByScroll = document.body.scrollHeight > beforeHeight;

        if (!grewByButton && !grewByScroll && pendingButtons().length === 0) {
          emptyPasses++;
          if (emptyPasses >= 2) break; // two clean passes with nothing new -> done
        } else {
          emptyPasses = 0;
        }
        continue;
      }

      emptyPasses = 0;
      const btn = buttons[0];
      btn.setAttribute(MARK, "1"); // mark BEFORE click so we never re-press this node
      btn.scrollIntoView({ block: "center", behavior: "instant" });
      btn.click();
      state.added++;
      report();
      await sleep(randDelay(minDelay, maxDelay));
    }

    state.running = false;
    chrome.runtime
      .sendMessage({ type: "DONE", added: state.added })
      .catch(() => {});
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "START") {
      let min = Math.max(100, Number(msg.minDelay) || 800);
      let max = Math.max(min, Number(msg.maxDelay) || 1000);
      run(min, max);
      sendResponse({ ok: true, running: true });
    } else if (msg.type === "STOP") {
      state.running = false;
      sendResponse({ ok: true, running: false });
    } else if (msg.type === "GET_STATUS") {
      sendResponse({
        ok: true,
        running: state.running,
        added: state.added,
        remaining: pendingButtons().length,
      });
    }
    return true; // keep the message channel open for async sendResponse
  });
})();
