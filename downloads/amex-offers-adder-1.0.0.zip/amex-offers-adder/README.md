# Amex Offers — Add All

A small Chrome (MV3) extension that loops through every offer on your American
Express Offers page and clicks **Add to Card** for each one.

## Why your old console snippet stopped working

```js
var buttons = document.querySelectorAll('button[title="Add to Card"]'); // ← no longer matches
```

Three problems:

1. **The selector is stale.** Amex changed the button. The title is now
   `add to list card` and, more usefully, it carries a stable
   `data-testid="merchantOfferListAddButton"`. The old `title="Add to Card"`
   matched zero elements, so nothing happened.
2. **Static NodeList.** The snippet captured all buttons once. Each click
   re-renders the offer card, so the cached list went stale immediately.
3. **No scrolling.** Offers further down lazy-load. The snippet only ever saw
   the first screenful.

This extension targets the stable `data-testid`, **re-queries after every
click**, marks buttons it already pressed (so it can never loop on one), and
**auto-scrolls / clicks "load more"** until no offers remain.

## Install (Load Unpacked)

1. Open `chrome://extensions` in Chrome (or Brave).
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this `amex-offers-adder` folder.
4. Pin the extension if you like (puzzle-piece icon → pin).

## Use

1. Log in to American Express and open your **Offers** page
   (`https://global.americanexpress.com/offers/...`).
2. Click the extension icon.
3. (Optional) Adjust the delay between clicks — default **1500 ms**. Slower is
   safer if the page feels sluggish.
4. Click **Add all offers**. Watch the count climb; click **Stop** any time.

The loop runs in the page even if you close the popup. It finishes on its own
once every offer is added.

## If it ever bricks again

It'll almost certainly be the selector again (Amex redeploys often). Right-click
an **Add to Card** button → **Inspect**, find the new `data-testid` (or another
stable attribute), and update `SELECTOR` at the top of `content.js`.
